document.getElementById('insertButton').addEventListener('click', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do botão

    const nomeProduto = document.getElementById('inputnomeProduto').value;
    const descricaoProduto = document.getElementById('inputdescricaoProduto').value;
    const precoProduto = document.getElementById('inputprecoProduto').value;
    const quantidadeProduto = document.getElementById('inputquantidadeProduto').value;
    const categoriaProduto = document.getElementById('inputcategoriaProduto').value;

    // Chamada à API para enviar os dados
    fetch('http://localhost:3000/api/produto', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nomeProduto, descricaoProduto, precoProduto, quantidadeProduto, categoriaProduto })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro na resposta da rede');
        }
        return response.json();
    })
    .then(data => {
        console.log('Sucesso:', data);
        alert('Produto cadastrado com sucesso!'); // Mensagem de sucesso

        // Limpar o formulário
        document.getElementById('cadastro-form').reset();

        // Recarregar a tabela com todos os produtos
        carregarProdutos();
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Ocorreu um erro ao cadastrar o produto.'); // Mensagem de erro
    });
});

document.getElementById('deleteButton').onclick = async function() {
    const produtoId = prompt("Digite o ID do produto que deseja deletar:"); // Solicita o ID do produto
    if (produtoId) {
        const confirmDelete = confirm('Tem certeza que deseja deletar este produto?');
        if (confirmDelete) {
            await deleteProduto(produtoId); // Chama a função para deletar o produto
            carregarProdutos();
        }
    }
};

async function deleteProduto(id) {
    try {
        const response = await fetch(`http://localhost:3000/api/produto/${id}`, {
            method: 'DELETE', // Método para deletar
        });

        if (response.ok) {
            alert('Produto deletado com sucesso!');
            // Aqui você pode adicionar lógica para atualizar a interface, se necessário
        } else {
            alert('Erro ao deletar produto');
        }
    } catch (error) {
        console.error('Erro ao deletar produto:', error);
    }
}

// Função para carregar todos os produtos ao carregar a página
function carregarProdutos() {
    fetch('http://localhost:3000/api/produto') // Rota que devolve todos os produtos
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar produtos');
            }
            return response.json();
        })
        .then(produtos => {
            const tabelaProdutos = document.getElementById('produtos-list');
            tabelaProdutos.innerHTML = ''; // Limpa a tabela antes de preenchê-la

            produtos.forEach(produto => {
                const novaLinha = document.createElement('tr');
                novaLinha.innerHTML = `
                    <td>${produto.id}</td>
                    <td>${produto.nomeProduto}</td>
                    <td>${produto.descricaoProduto}</td>
                    <td>${produto.precoProduto}</td>
                    <td>${produto.quantidadeProduto}</td>
                    <td>${produto.categoriaProduto}</td>
                    <td><button class="btn btn-info" onclick="preencherFormulario(${produto.id})">Selecionar</button></td>
                `;
                tabelaProdutos.appendChild(novaLinha);
            });
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Ocorreu um erro ao carregar a lista de produtos.');
        });
}

// Função para preencher o formulário com os dados do produto selecionado
function preencherFormulario(produtoId) {
    fetch(`http://localhost:3000/api/produto/${produtoId}`) // Supondo que essa rota retorne um produto específico pelo ID
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar produto');
            }
            return response.json();
        })
        .then(produto => {
            // Preenche os campos do formulário com os dados do produto
            document.getElementById('inputnomeProduto').value = produto.nomeProduto;
            document.getElementById('inputdescricaoProduto').value = produto.descricaoProduto;
            document.getElementById('inputprecoProduto').value = produto.precoProduto;
            document.getElementById('inputquantidadeProduto').value = produto.quantidadeProduto;
            document.getElementById('inputcategoriaProduto').value = produto.categoriaProduto;

            // Adiciona um atributo de ID ao formulário para saber que produto está sendo editado
            document.getElementById('cadastro-form').setAttribute('data-produto-id', produto.id);
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Ocorreu um erro ao carregar os dados do produto.');
        });
}

// Chama a função para carregar os produtos quando a página for carregada
document.addEventListener('DOMContentLoaded', carregarProdutos);
