const express = require('express');
const carrinhoRoutes = require('./routes/carrinho/carrinhoRoutes');
const clienteRoutes = require('./routes/cliente/clienteRoutes');
const produtoRoutes = require('./routes/produto/produtoRoutes');
const contatoRoutes = require('./routes/contato/contatoRoutes');
const cors = require('cors');

const app = express();

// Habilitar CORS
app.use(cors());

app.use(express.json());
console.log('Rota 01')
app.use('/api', carrinhoRoutes);
app.use('/api', clienteRoutes);
app.use('/api', produtoRoutes);
app.use('/api', contatoRoutes);

module.exports = app;