const Produto = require('../../models/produto/Produto'); // Importando o modelo de Produto

class ProdutoController {
  
  // Adicionar um novo produto
  async adicionarProduto(req, res) {
    const { nomeProduto, descricaoProduto, precoProduto, quantidadeProduto, categoriaProduto } = req.body;
    
    try {
      console.log('Dados recebidos:', req.body);
      
      // Criando o novo produto no banco de dados
      const novoProduto = await Produto.create({
        nome: nomeProduto,
        descricao: descricaoProduto,
        preco: precoProduto,
        quantidade_estoque: quantidadeProduto,
        categoria_id: categoriaProduto // Supondo que categoria seja uma chave estrangeira
      });
      
      console.log('Produto criado com sucesso:', novoProduto);
      
      // Retornando a resposta com o produto criado
      res.status(201).json(novoProduto);
    } catch (error) {
      console.error('Erro ao criar o produto:', error);
      res.status(500).json({ error: 'Erro ao criar o produto', descricao: error.message });
    }
  }

  // Listar todos os produtos
  async listarProdutos(req, res) {
    try {
      const produtos = await Produto.findAll();
      res.status(200).json(produtos);
    } catch (error) {
      res.status(500).json({ error: 'Erro ao buscar Produtos', descricao: error.message });
    }
  }

  // Buscar um produto por ID
  async buscarProdutoPorId(req, res) {
    const { id } = req.params;
    
    try {
      const produto = await Produto.findOne({ where: { id } });
      
      if (!produto) {
        return res.status(404).json({ message: 'Produto não encontrado' });
      }
      
      res.status(200).json(produto);
    } catch (error) {
      res.status(500).json({ error: 'Erro ao buscar Produto', descricao: error.message });
    }
  }

  // Atualizar as informações de um produto
  async atualizarProduto(req, res) {
    const { id } = req.params;
    const { nomeProduto, descricaoProduto, precoProduto, quantidadeProduto, categoriaProduto } = req.body;
    
    try {
      const produto = await Produto.update(
        {
          nome: nomeProduto,
          descricao: descricaoProduto,
          preco: precoProduto,
          quantidade_estoque: quantidadeProduto,
          categoria_id: categoriaProduto
        },
        { where: { id } }
      );
      
      if (produto[0] === 0) {
        return res.status(404).json({ message: 'Produto não encontrado para atualização' });
      }
      
      res.status(202).json({ message: 'Produto atualizado com sucesso!' });
    } catch (error) {
      console.error('Erro ao atualizar o produto:', error);
      res.status(500).json({ error: 'Erro ao atualizar o produto', descricao: error.message });
    }
  }

  // Remover um produto por ID
  async removerProduto(req, res) {
    const { id } = req.params;
    
    try {
      const produto = await Produto.destroy({ where: { id } });
      
      if (!produto) {
        return res.status(404).json({ message: 'Produto não encontrado para remoção' });
      }
      
      res.status(202).json({ message: 'Produto removido com sucesso.' });
    } catch (error) {
      console.error('Erro ao remover produto:', error);
      res.status(500).json({ error: 'Erro ao remover produto', descricao: error.message });
    }
  }
}

module.exports = new ProdutoController();
