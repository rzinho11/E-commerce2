const express = require('express');
const router = express.Router();
const ContatoController = require('../../controllers/contato/contatoController');

router.post('/enviar', ContatoController.enviarMensagem);

module.exports = router;