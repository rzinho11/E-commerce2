const express = require('express');
const carrinhoController = require('../../controllers/carrinho/carrinhoController');

const router = express.Router();

router.get('/carrinho/:usuarioId', carrinhoController.listarCarrinho);
router.post('/carrinho/:usuarioId/produto', carrinhoController.adicionarProduto);
router.put('/carrinho/:usuarioId/produto/:produtoId', carrinhoController.atualizarQuantidadeProduto);
router.delete('/carrinho/:usuarioId/produto/:produtoId', carrinhoController.removerProdutoCarrinho);
router.delete('/carrinho/:usuarioId', carrinhoController.limparCarrinho);

module.exports = router;
