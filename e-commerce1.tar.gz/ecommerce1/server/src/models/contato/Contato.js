const { DataTypes, Model } = require('sequelize');
const sequelize = require('../../config/database'); // Ajuste o caminho conforme necessário

class Contato extends Model {}

Contato.init({
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      isEmail: true,
    }
  },
  mensagem: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  criadoEm: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  }
}, {
  sequelize,
  modelName: 'Contato',
  tableName: 'contatos',
  timestamps: false
});

module.exports = Contato;